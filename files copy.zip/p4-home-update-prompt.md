Update the new homepage (index.html) and site photos. Keep the existing layout, design tokens and components. Only change what's listed below.

PHOTOS
New files are in public/images/ (they replace the old hero.jpg / coaching-card.jpg if names clash, otherwise update the paths):
- hero.jpg, coaching-card.jpg
- cameron-before.jpg, cameron-now.jpg, ethan-before.jpg, ethan-now.jpg
- cameron-coach.jpg, ethan-coach.jpg

1. Remove the blue duotone/tint treatment from ALL photos across the whole site (home, guaranteed-coaching, shop). Show photos in their natural colour. Keep any dark gradient overlays only where text sits on top of an image and needs contrast.
2. Hero: use hero.jpg.
3. Coaching card: use coaching-card.jpg.
4. Results flip cards: wire up the real photos. Cameron: front = cameron-now.jpg, back = cameron-before.jpg. Ethan: front = ethan-now.jpg, back = ethan-before.jpg. Use object-fit: cover with object-position top so heads never get cut off.
5. Coaches section: Cameron = cameron-coach.jpg, Ethan = ethan-coach.jpg. object-position top.

COPY (use exactly, no em dashes)

Hero
- Eyebrow: PLUS 4 PERFORMANCE
- H1: "1:1 online coaching." then on a new line in accent colour: "Results guaranteed."
- Sub: "We're Cameron and Ethan. We coach you 1:1, check in every week and keep you accountable. Put the work in and don't hit your goal? You get your money back."
- Buttons unchanged: "Guaranteed Coaching" and "Shop Clothing"

Offers section
- Remove the "WHAT WE DO" eyebrow. Heading: "Work with us."
- Coaching card
  Eyebrow: 16-WEEK GUARANTEED COACHING
  Heading: "Hit your goal or your money back."
  Body: "16 weeks 1:1 with us. We go through every session, check your form and keep you accountable twice a week. Put the work in, and if you don't hit your goal, you get your money back."
  Left: "Price on application"  Button: "Book a Call"
- Clothing card
  Eyebrow: CLOTHING
  Heading: "Made for training."
  Body: "Clothing we designed and wear ourselves. Made to order and delivered to your door."
  Left: "From £20"  Button: "Shop Now"

Replace the whole "WHY PLUS 4" section (the +4 Reps / +4% Effort / +4 Discipline columns) with a "How it works" section:
- Eyebrow: HOW IT WORKS
- Heading: "Three steps. No faff."
- Three numbered steps in a row (stack on mobile), large step number in accent:
  01 "Book a call." / "We talk about where you're at and what you want to change."
  02 "We build your plan." / "Training and food, built around your life, not the other way round."
  03 "We check in every week." / "Every session reviewed, every week. Until you hit it."
- Under the steps, a "Book a Call" button (TidyCal link, filled style).

Results section: keep as is (heading "We've done it ourselves.", sub "Tap a photo to see where we started.").

Coaches section: keep copy as is.

Email sign-up
- Heading: "Don't miss a drop."
- Body: "New clothing and coaching spaces, straight to your inbox. No spam."
- Button: "Sign Up"

Also update the homepage meta description to: "1:1 online coaching with a results guarantee, and gym clothing from Cameron and Ethan at Plus 4 Performance."

PROCESS
- Do NOT commit or push.
- When done, restart the local preview and give me the link. List the files changed.
